package com.example.islam_40242307_programmingassignment1;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.appcompat.app.ActionBar;
import android.widget.EditText;
import android.text.InputFilter;
import android.widget.Button;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity {

    private EditText editTextButton1Name, editTextButton2Name, editTextButton3Name, editTextMaxEvents;
    private SharedPreferencesHelper preferencesHelper;
    private boolean isEditModeEnabled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle("Settings");
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        preferencesHelper = new SharedPreferencesHelper(this);
        editTextButton1Name = findViewById(R.id.edit_button_1_name);
        editTextButton2Name = findViewById(R.id.edit_button_2_name);
        editTextButton3Name = findViewById(R.id.edit_button_3_name);
        editTextMaxEvents = findViewById(R.id.edit_max_events);

        editTextButton1Name.setText(preferencesHelper.getButton1Name());
        editTextButton2Name.setText(preferencesHelper.getButton2Name());
        editTextButton3Name.setText(preferencesHelper.getButton3Name());

        InputFilter[] alphaFilter = new InputFilter[]{
                new InputFilter.LengthFilter(20),
                (source, start, end, dest, start2, end2) -> {
                    for (int i = start; i < end; i++) {
                        if (!Character.isLetter(source.charAt(i)) && !Character.isWhitespace(source.charAt(i))) {
                            return "";
                        }
                    }
                    return null;
                }
        };

        editTextButton1Name.setFilters(alphaFilter);
        editTextButton2Name.setFilters(alphaFilter);
        editTextButton3Name.setFilters(alphaFilter);

        InputFilter[] maxLengthFilter = new InputFilter[]{new InputFilter.LengthFilter(6)};
        editTextMaxEvents.setFilters(maxLengthFilter);

        Button buttonSaveSettings = findViewById(R.id.btn_save_settings);
        buttonSaveSettings.setOnClickListener(v -> {
            String button1Name = editTextButton1Name.getText().toString().trim();
            String button2Name = editTextButton2Name.getText().toString().trim();
            String button3Name = editTextButton3Name.getText().toString().trim();

            try {
                int maxEvents = Integer.parseInt(editTextMaxEvents.getText().toString().trim());
                if (maxEvents < 5 || maxEvents > 200) {
                    Toast.makeText(SettingsActivity.this, "Please enter a valid number of max events (5-200).", Toast.LENGTH_SHORT).show();
                    return;
                }
                preferencesHelper.saveMaxEvents(maxEvents);
            } catch (Exception e) {
                Toast.makeText(SettingsActivity.this, "Please enter a valid number for max events.", Toast.LENGTH_SHORT).show();
                return;
            }

            preferencesHelper.saveButtonNames(button1Name, button2Name, button3Name);
            Toast.makeText(SettingsActivity.this, "Settings saved successfully.", Toast.LENGTH_SHORT).show();
            finish();
        });

        Button buttonEditMode = findViewById(R.id.edit_button);
        buttonEditMode.setOnClickListener(v -> toggleEditMode());
    }

    private void toggleEditMode() {
        isEditModeEnabled = !isEditModeEnabled;
        editTextButton1Name.setEnabled(isEditModeEnabled);
        editTextButton2Name.setEnabled(isEditModeEnabled);
        editTextButton3Name.setEnabled(isEditModeEnabled);
        editTextMaxEvents.setEnabled(isEditModeEnabled);
    }
}
