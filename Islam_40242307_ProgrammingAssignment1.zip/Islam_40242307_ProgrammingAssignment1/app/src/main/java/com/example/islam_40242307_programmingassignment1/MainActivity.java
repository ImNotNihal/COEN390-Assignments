package com.example.islam_40242307_programmingassignment1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private SharedPreferencesHelper preferencesHelper;
    private TextView textViewTotalCount;
    private int eventCountA, eventCountB, eventCountC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        preferencesHelper = new SharedPreferencesHelper(this);
        if (preferencesHelper.getButton1Name().isEmpty() || preferencesHelper.getButton2Name().isEmpty() || preferencesHelper.getButton3Name().isEmpty()) {
            Intent settingsIntent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(settingsIntent);
            finish();
            return;
        }

        Button buttonSettings = findViewById(R.id.settingsBtn);
        buttonSettings.setOnClickListener(view -> {
            Intent settingsIntent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(settingsIntent);
        });

        Button buttonEventA = findViewById(R.id.btn_event_a);
        Button buttonEventB = findViewById(R.id.btn_event_b);
        Button buttonEventC = findViewById(R.id.btn_event_c);
        Button buttonShowData = findViewById(R.id.dataBtn);

        textViewTotalCount = findViewById(R.id.totalCount);
        eventCountA = preferencesHelper.getEventA();
        eventCountB = preferencesHelper.getEventB();
        eventCountC = preferencesHelper.getEventC();
        updateTotalCountDisplay();

        // Event A Button
        buttonEventA.setText(preferencesHelper.getButton1Name());
        buttonEventA.setOnClickListener(v -> {
                eventCountA++;
                preferencesHelper.saveEventCounts(eventCountA, eventCountB, eventCountC);
                updateTotalCountDisplay();

                List<String> eventHistory = preferencesHelper.getEventHistory();
                eventHistory.add(preferencesHelper.getButton1Name() + " occurred");
                preferencesHelper.saveEventHistory(eventHistory);
        });

        // Event B Button
        buttonEventB.setText(preferencesHelper.getButton2Name());
        buttonEventB.setOnClickListener(v -> {
                eventCountB++;
                preferencesHelper.saveEventCounts(eventCountA, eventCountB, eventCountC);
                updateTotalCountDisplay();

                List<String> eventHistory = preferencesHelper.getEventHistory();
                eventHistory.add(preferencesHelper.getButton2Name() + " occurred");
                preferencesHelper.saveEventHistory(eventHistory);
        });

        // Event C Button
        buttonEventC.setText(preferencesHelper.getButton3Name());
        buttonEventC.setOnClickListener(v -> {
                eventCountC++;
                preferencesHelper.saveEventCounts(eventCountA, eventCountB, eventCountC);
                updateTotalCountDisplay();

                List<String> eventHistory = preferencesHelper.getEventHistory();
                eventHistory.add(preferencesHelper.getButton3Name() + " occurred");
                preferencesHelper.saveEventHistory(eventHistory);
        });

        buttonShowData.setOnClickListener(v -> {
            Intent dataActivityIntent = new Intent(MainActivity.this, dataActivity.class);
            startActivity(dataActivityIntent);
        });
    }

    private void updateTotalCountDisplay() {
        int total = eventCountA + eventCountB + eventCountC;
        textViewTotalCount.setText(getString(R.string.total_count, total));
    }
}
