package com.example.islam_40242307_programmingassignment1;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import java.util.ArrayList;
import java.util.List;

public class dataActivity extends AppCompatActivity {

    private boolean isDisplayingEventNames = true;
    private final ArrayList<String> eventHistoryList = new ArrayList<>();
    private final ArrayList<String> eventButtonList = new ArrayList<>();
    private ArrayAdapter<String> eventHistoryAdapter;
    private final SharedPreferencesHelper preferencesHelper;

    public dataActivity(SharedPreferencesHelper preferencesHelper) {
        this.preferencesHelper = preferencesHelper;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_data);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle("Event Data Activity");
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        TextView textViewEventACount = findViewById(R.id.event_a_count);
        TextView textViewEventBCount = findViewById(R.id.event_b_count);
        TextView textViewEventCCount = findViewById(R.id.event_c_count);
        TextView textViewTotalEventCount = findViewById(R.id.total_count);
        ListView eventHistoryListView = findViewById(R.id.event_list);

        SharedPreferencesHelper sharedPreferencesHelper = new SharedPreferencesHelper(this);

        int countEventA = sharedPreferencesHelper.getEventA();
        int countEventB = sharedPreferencesHelper.getEventB();
        int countEventC = sharedPreferencesHelper.getEventC();
        int totalCount = countEventA + countEventB + countEventC;

        textViewEventACount.setText(getString(R.string.event_a_count, countEventA));
        textViewEventBCount.setText(getString(R.string.event_b_count, countEventB));
        textViewEventCCount.setText(getString(R.string.event_c_count, countEventC));
        textViewTotalEventCount.setText(getString(R.string.total_event_count, totalCount));

        loadEventHistory();

        eventHistoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventHistoryList);
        eventHistoryListView.setAdapter(eventHistoryAdapter);
    }

    private void loadEventHistory() {
        List<String> savedHistory = preferencesHelper.getEventHistory();
        if (!savedHistory.isEmpty()) {
            eventHistoryList.addAll(savedHistory);

            for (String event : savedHistory) {
                switch (event) {
                    case "Event A":
                        eventButtonList.add("1");
                        break;
                    case "Event B":
                        eventButtonList.add("2");
                        break;
                    case "Event C":
                        eventButtonList.add("3");
                        break;
                    default:
                        eventButtonList.add("Unknown");
                        break;
                }
            }
        } else {
            Toast.makeText(this, "No event history found.", Toast.LENGTH_SHORT).show();
        }
        eventHistoryAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_data_activity, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        } else if (item.getItemId() == R.id.toggle_event_names) {
            toggleEventDisplayMode();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void toggleEventDisplayMode() {
        isDisplayingEventNames = !isDisplayingEventNames;
        if (isDisplayingEventNames) {
            eventHistoryAdapter.clear();
            eventHistoryAdapter.addAll(eventHistoryList);
            Toast.makeText(this, "Displaying Event Names", Toast.LENGTH_SHORT).show();
        } else {
            eventHistoryAdapter.clear();
            eventHistoryAdapter.addAll(eventButtonList);
            Toast.makeText(this, "Displaying Button Numbers", Toast.LENGTH_SHORT).show();
        }
        eventHistoryAdapter.notifyDataSetChanged();
    }
}
