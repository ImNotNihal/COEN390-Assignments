package com.example.islam_40242307_programmingassignment1;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SharedPreferencesHelper {

    private final SharedPreferences sharedPreferences;

    public SharedPreferencesHelper(Context context) {
        sharedPreferences = context.getSharedPreferences("ProfilePreferences", Context.MODE_PRIVATE);
    }

    public String getButton1Name() {
        return sharedPreferences.getString("button1", "Event A");
    }

    public String getButton2Name() {
        return sharedPreferences.getString("button2", "Event B");
    }

    public String getButton3Name() {
        return sharedPreferences.getString("button3", "Event C");
    }

    public int getEventA() {
        return sharedPreferences.getInt("eventA", 0);
    }

    public int getEventB() {
        return sharedPreferences.getInt("eventB", 0);
    }

    public int getEventC() {
        return sharedPreferences.getInt("eventC", 0);
    }

    public int getMaxEvents() {
        return sharedPreferences.getInt("maxEvents", 100);  // Default value is 100
    }

    public void saveButtonNames(String button1, String button2, String button3) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("button1", button1);
        editor.putString("button2", button2);
        editor.putString("button3", button3);
        editor.apply();
    }

    public void saveEventCounts(int eventA, int eventB, int eventC) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("eventA", eventA);
        editor.putInt("eventB", eventB);
        editor.putInt("eventC", eventC);
        editor.apply();
    }

    public void saveMaxEvents(int maxEvents) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("maxEvents", maxEvents);
        editor.apply();
    }

    public void saveEventHistory(List<String> events) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String csv = TextUtils.join(",", events);
        editor.putString("eventHistory", csv);
        editor.apply();
    }

    public List<String> getEventHistory() {
        String csv = sharedPreferences.getString("eventHistory", "");
        return new ArrayList<>(Arrays.asList(csv.split(",")));
    }
}
