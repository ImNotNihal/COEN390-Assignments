package com.example.a40242307_assignment2;

public class Access {
    private int accessID;
    private final int profileID;
    private final String accessType;
    private final String timestamp;

    // Constructor for Access
    public Access(int accessID, int profileID, String accessType, String timestamp) {
        this.accessID = accessID;
        this.profileID = profileID;
        this.accessType = accessType;
        this.timestamp = timestamp;
    }

    // Overloaded constructor for cases without accessID (when inserting new entries)
    public Access(int profileID, String accessType, String timestamp) {
        this.profileID = profileID;
        this.accessType = accessType;
        this.timestamp = timestamp;
    }

    // Getters and Setters
    public int getProfileID() {
        return profileID;
    }

    public String getAccessType() {
        return accessType;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
