package com.example.a40242307_assignment2;

public class Profile {
    private int profileID;
    private String name;
    private final String surname;
    private final float gpa;
    private final String creationDate;

    // Constructor for Profile
    public Profile(int profileID, String name, String surname, float gpa, String creationDate) {
        this.profileID = profileID;
        this.name = name;
        this.surname = surname;
        this.gpa = gpa;
        this.creationDate = creationDate;
    }

    // Getters and Setters
    public int getProfileID() {
        return profileID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public float getGpa() {
        return gpa;
    }

    public String getCreationDate() {
        return creationDate;
    }
}
