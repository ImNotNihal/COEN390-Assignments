package com.example.a40242307_assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity{

    private DatabaseHelper databaseHelper;
    private ListView profileListView;
    private TextView headerTextView;
    private List<Profile> profileList = new ArrayList<>();
    private boolean sortByID = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);
        profileListView = findViewById(R.id.profileListView);
        headerTextView = findViewById(R.id.headerTextView);
        FloatingActionButton fab = findViewById(R.id.fab);

        loadProfiles();

        // Setup Floating Action Button to open InsertProfile DialogFragment
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InsertProfileDialogFragment dialogFragment = new InsertProfileDialogFragment();
                dialogFragment.show(getSupportFragmentManager(), "InsertProfileDialogFragment");
            }
        });

        // Set up list item click listener to open ProfileActivity
        profileListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Profile selectedProfile = profileList.get(position);
                Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                intent.putExtra("profileID", selectedProfile.getProfileID());
                startActivity(intent);
            }
        });
    }

    // Load profiles from database and update the ListView
    private void loadProfiles() {
        profileList = databaseHelper.getAllProfiles();
        updateDisplayMode();
    }

    // Update ListView based on current sort mode and profile count in the header
    private void updateDisplayMode() {
        List<String> profileDisplayList = new ArrayList<>();
        for (Profile profile : profileList) {
            if (sortByID) {
                profileDisplayList.add("ID: " + profile.getProfileID());
            } else {
                profileDisplayList.add(profile.getSurname() + ", " + profile.getName());
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, profileDisplayList);
        profileListView.setAdapter(adapter);

        headerTextView.setText("Total Profiles: " + profileList.size() + " | Display Mode: " + (sortByID ? "By ID" : "By Name"));
    }

    // Menu for toggling display mode
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_toggle_display) {
            sortByID = !sortByID;
            sortProfiles();
            updateDisplayMode();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Sort profiles based on selected mode
    private void sortProfiles() {
        if (sortByID) {
            profileList.sort(Comparator.comparingInt(Profile::getProfileID));
        } else {
            profileList.sort(Comparator.comparing(Profile::getSurname));
        }
    }

    // Refresh profiles when returning from ProfileActivity or after adding a new profile
    @Override
    protected void onResume() {
        super.onResume();
        loadProfiles();
    }
}
