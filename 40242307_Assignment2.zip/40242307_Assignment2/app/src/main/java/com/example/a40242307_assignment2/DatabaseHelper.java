package com.example.a40242307_assignment2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Constants
    private static final String DATABASE_NAME = "ProfilesDatabase";
    private static final int DATABASE_VERSION = 1;

    // Table and Column Names
    private static final String TABLE_PROFILE = "Profile";
    private static final String COLUMN_PROFILE_ID = "ProfileID";
    private static final String COLUMN_NAME = "Name";
    private static final String COLUMN_SURNAME = "Surname";
    private static final String COLUMN_GPA = "ProfileGPA";
    private static final String COLUMN_CREATION_DATE = "CreationDate";

    private static final String TABLE_ACCESS = "Access";
    private static final String COLUMN_ACCESS_ID = "AccessID";
    private static final String COLUMN_PROFILE_ID_FK = "ProfileID"; // Foreign key
    private static final String COLUMN_ACCESS_TYPE = "AccessType";
    private static final String COLUMN_TIMESTAMP = "Timestamp";

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL command to create Profile table
        String createProfileTable = "CREATE TABLE " + TABLE_PROFILE + " (" +
                COLUMN_PROFILE_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_SURNAME + " TEXT, " +
                COLUMN_GPA + " REAL, " +
                COLUMN_CREATION_DATE + " TEXT)";
        db.execSQL(createProfileTable);

        // SQL command to create Access table
        String createAccessTable = "CREATE TABLE " + TABLE_ACCESS + " (" +
                COLUMN_ACCESS_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_PROFILE_ID_FK + " INTEGER, " +
                COLUMN_ACCESS_TYPE + " TEXT, " +
                COLUMN_TIMESTAMP + " TEXT, " +
                "FOREIGN KEY(" + COLUMN_PROFILE_ID_FK + ") REFERENCES " + TABLE_PROFILE + "(" + COLUMN_PROFILE_ID + "))";
        db.execSQL(createAccessTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROFILE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACCESS);
        onCreate(db);
    }

    // Method to add a new profile to the Profile table
    public long addProfile(Profile profile) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PROFILE_ID, profile.getProfileID());
        values.put(COLUMN_NAME, profile.getName());
        values.put(COLUMN_SURNAME, profile.getSurname());
        values.put(COLUMN_GPA, profile.getGpa());
        values.put(COLUMN_CREATION_DATE, profile.getCreationDate());
        long id = db.insert(TABLE_PROFILE, null, values);

        // Log "created" event in Access table
        addAccess(new Access(profile.getProfileID(), "created", getCurrentTimestamp()));

        db.close();
        return id;
    }

    // Method to add a new access entry to the Access table
    public void addAccess(Access access) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PROFILE_ID_FK, access.getProfileID());
        values.put(COLUMN_ACCESS_TYPE, access.getAccessType());
        values.put(COLUMN_TIMESTAMP, access.getTimestamp());
        long id = db.insert(TABLE_ACCESS, null, values);
        db.close();
    }

    // Method to retrieve all profiles
    public List<Profile> getAllProfiles() {
        List<Profile> profileList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PROFILE, null, null, null, null, null, null);
        while (cursor.moveToNext()) {
            Profile profile = new Profile(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_PROFILE_ID)), cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)), cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SURNAME)), cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_GPA)), cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CREATION_DATE))
            );
            profileList.add(profile);
        }
        cursor.close();
        db.close();
        return profileList;
    }

    // Method to retrieve access history for a specific profile
    public List<Access> getAccessEntriesForProfile(int profileID) {
        List<Access> accessList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ACCESS, null, COLUMN_PROFILE_ID_FK + "=?", new String[]{String.valueOf(profileID)}, null, null, null);
        while (cursor.moveToNext()) {
            Access access = new Access(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ACCESS_ID)), cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_PROFILE_ID_FK)), cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ACCESS_TYPE)), cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP))
            );
            accessList.add(access);
        }
        cursor.close();
        db.close();
        return accessList;
    }

    // Method to delete a profile and log a "deleted" event
    public void deleteProfile(int profileID) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_PROFILE, COLUMN_PROFILE_ID + "=?", new String[]{String.valueOf(profileID)});
        addAccess(new Access(profileID, "deleted", getCurrentTimestamp()));
        db.close();
    }

    // Helper method to get the current timestamp
    private String getCurrentTimestamp() {
        return new SimpleDateFormat("yyyy-MM-dd @ HH:mm:ss", Locale.getDefault()).format(new Date());
    }
}
