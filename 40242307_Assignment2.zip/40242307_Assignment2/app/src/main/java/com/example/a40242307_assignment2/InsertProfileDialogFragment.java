package com.example.a40242307_assignment2;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class InsertProfileDialogFragment extends DialogFragment{

    private EditText nameEditText;
    private EditText surnameEditText;
    private EditText profileIdEditText;
    private EditText gpaEditText;
    private DatabaseHelper databaseHelper;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        databaseHelper = new DatabaseHelper(requireContext());

        // Inflate the dialog layout
        View view = getLayoutInflater().inflate(R.layout.dialog_insert_profile, null);
        nameEditText = view.findViewById(R.id.nameEditText);
        surnameEditText = view.findViewById(R.id.surnameEditText);
        profileIdEditText = view.findViewById(R.id.profileIdEditText);
        gpaEditText = view.findViewById(R.id.gpaEditText);

        // Create and configure dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setView(view).setTitle("Add New Profile").setPositiveButton("Save", null).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int x) {
                dialog.dismiss();
            }
        });

        // Create AlertDialog to override positive button click after it's shown
        final AlertDialog dialog = builder.create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                Button saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                saveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        saveProfile();
                    }
                });
            }
        });
        return dialog;
    }

    // Save profile to database if input is valid
    private void saveProfile() {
        String name = nameEditText.getText().toString().trim();
        String surname = surnameEditText.getText().toString().trim();
        String profileIdStr = profileIdEditText.getText().toString().trim();
        String gpaStr = gpaEditText.getText().toString().trim();

        // Validate inputs
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(surname) || TextUtils.isEmpty(profileIdStr) || TextUtils.isEmpty(gpaStr)) {
            Toast.makeText(getContext(), "All fields are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Parse and validate Profile ID
        int profileId;
        try {
            profileId = Integer.parseInt(profileIdStr);
            if (profileId < 10000000 || profileId > 99999999) {
                Toast.makeText(getContext(), "Profile ID must be an 8-digit number between 10000000 and 99999999.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (databaseHelper.getAllProfiles().stream().anyMatch(profile -> profile.getProfileID() == profileId)) {
                Toast.makeText(getContext(), "Profile ID already exists.", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Profile ID must be a valid 8-digit number.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Parse and validate GPA
        float gpa;
        try {
            gpa = Float.parseFloat(gpaStr);
            if (gpa < 0 || gpa > 4.3) {
                Toast.makeText(getContext(), "GPA must be between 0 and 4.3.", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "GPA must be a valid number between 0 and 4.3.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insert profile into database
        Profile newProfile = new Profile(profileId, name, surname, gpa, getCurrentTimestamp());
        long result = databaseHelper.addProfile(newProfile);

        if (result != -1) {
            Toast.makeText(getContext(), "Profile added successfully.", Toast.LENGTH_SHORT).show();
            dismiss(); // Close dialog
        } else {
            Toast.makeText(getContext(), "Error adding profile. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper method to get current timestamp
    private String getCurrentTimestamp() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd @ HH:mm:ss", java.util.Locale.getDefault()).format(new java.util.Date());
    }
}
