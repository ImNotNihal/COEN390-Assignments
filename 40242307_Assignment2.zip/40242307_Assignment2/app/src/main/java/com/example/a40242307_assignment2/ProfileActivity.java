package com.example.a40242307_assignment2;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ProfileActivity extends AppCompatActivity{

    private DatabaseHelper databaseHelper;
    private TextView nameTextView;
    private TextView surnameTextView;
    private TextView profileIdTextView;
    private TextView gpaTextView;
    private ListView accessHistoryListView;
    private int profileID;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        databaseHelper = new DatabaseHelper(this);

        // Initialize UI elements
        nameTextView = findViewById(R.id.nameTextView);
        surnameTextView = findViewById(R.id.surnameTextView);
        profileIdTextView = findViewById(R.id.profileIdTextView);
        gpaTextView = findViewById(R.id.gpaTextView);
        accessHistoryListView = findViewById(R.id.accessHistoryListView);
        Button deleteButton = findViewById(R.id.deleteButton);

        // Enable up navigation to return to MainActivity
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        // Retrieve the profile ID from the intent
        profileID = getIntent().getIntExtra("profileID", -1);
        if (profileID != -1) {
            loadProfileDetails();
            loadAccessHistory();
            logAccessEvent("opened");
        } else {
            Toast.makeText(this, "Error loading profile.", Toast.LENGTH_SHORT).show();
            finish();
        }

        // Set delete button action
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteProfile();
            }
        });
    }

    // Load profile details into TextViews
    private void loadProfileDetails() {
        Profile profile = databaseHelper.getAllProfiles().stream().filter(p -> p.getProfileID() == profileID).findFirst().orElse(null);

        if (profile != null) {
            nameTextView.setText("Name: " + profile.getName());
            surnameTextView.setText("Surname: " + profile.getSurname());
            profileIdTextView.setText("ID: " + profile.getProfileID());
            gpaTextView.setText("GPA: " + profile.getGpa());
        }
    }

    // Load access history for the selected profile
    private void loadAccessHistory() {
        List<Access> accessHistoryList = databaseHelper.getAccessEntriesForProfile(profileID);
        List<String> displayList = new ArrayList<>();
        for (Access access : accessHistoryList) {
            displayList.add(access.getAccessType() + ": " + access.getTimestamp());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayList);
        accessHistoryListView.setAdapter(adapter);
    }

    // Log an access event (e.g., "opened" or "deleted")
    private void logAccessEvent(String accessType) {
        String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd @ HH:mm:ss", java.util.Locale.getDefault()).format(new java.util.Date());
        Access access = new Access(profileID, accessType, timestamp);
        databaseHelper.addAccess(access);
    }

    // Delete the profile from the database
    private void deleteProfile() {
        databaseHelper.deleteProfile(profileID);
        logAccessEvent("profile deleted");
        Toast.makeText(this, "Profile deleted successfully.", Toast.LENGTH_SHORT).show();
        finish(); // Return to MainActivity
    }

    // Handle up navigation to return to MainActivity
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Log "closed" access event when exiting ProfileActivity
    @Override
    protected void onDestroy() {
        super.onDestroy();
        logAccessEvent("closed");
    }
}
